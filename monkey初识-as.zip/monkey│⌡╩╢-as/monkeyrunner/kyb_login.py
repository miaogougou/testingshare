from com.android.monkeyrunner import MonkeyRunner as mr
from com.android.monkeyrunner import MonkeyDevice as md
from com.android.monkeyrunner import MonkeyImage as mi

print("connect devices...")

device=mr.waitForConnection()

print(" install app")
device.installPackage('')

print("launch app...")
package='com.tal.kaoyan'
activity='com.tal.kaoyan.ui.activity.SplashActivity'
runComponent=package+'/'+activity

device.startActivity(component=runComponent)
mr.sleep(3)

print('touch cancel button')
device.touch(631,892,'DOWN_AND_UP')
mr.sleep(1)

print('touch skip button')
device.touch(804,69,'DOWN_AND_UP')
mr.sleep(1)

print('input username and password')
device.touch(197,376,'DOWN_AND_UP')
device.type('zxw1234')
mr.sleep(1)

device.touch(246,465,'DOWN_AND_UP')
device.type('zxw123456')
mr.sleep(1)


print('touch login button')
device.touch(368,629,'DOWN_AND_UP')
mr.sleep(1)


print('take snapshot')
screenshot=device.takeSnapshot()
screenshot.writeToFile('D:kyb.png','png')




